"""Quartermaster: Wi-Fi and Bluetooth wardriver for the M5Stack CardputerZero."""

__version__ = "1.0.3"
APP_NAME = "Quartermaster"
